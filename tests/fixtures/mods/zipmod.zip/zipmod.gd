extends Node


func _init_mod(api) -> void:
	pass


func _on_bootstrap() -> void:
	pass


func _on_post_bootstrap() -> void:
	pass


func _on_shutdown() -> void:
	pass


func _on_data_reloaded() -> void:
	pass
